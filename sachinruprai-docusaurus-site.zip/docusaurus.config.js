module.exports = {
  title: 'Sachin Ruprai Tech Hub',
  tagline: 'Technology, Architecture, AI and Leadership',
  url: 'https://sachinruprai.github.io',
  baseUrl: '/',
  organizationName: 'sachinruprai',
  projectName: 'sachinruprai.github.io',
};