import React from 'react';
export default function Home() {
  return <main><h1>Sachin Ruprai Tech Hub</h1></main>;
}